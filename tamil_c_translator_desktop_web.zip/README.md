# Tamil to C Translator

This project includes:

- A **Desktop application** built with Tkinter for translating Tamil keywords to C code.
- A **Web application** built with Flask to do the same via a web interface.
- A shared Tamil-to-C translation module.

## How to Run

### Desktop App

```bash
pip install tkinter
python desktop/desktop_app.py
```

### Web App

```bash
pip install -r requirements.txt
python web/web_app.py
```

Open http://127.0.0.1:5000 in your browser.

## Tamil-to-C Translator Module

See `tamil_to_c_translator.py` for keyword mapping and translation logic.

## Sample Usage

Enter Tamil C-style code in the input box and click Translate to get C code output.
