import tkinter as tk
from tkinter import scrolledtext, messagebox
from tamil_to_c_translator import tamil_to_c

class TamilToCApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Tamil to C Translator - Desktop")

        self.input_label = tk.Label(root, text="Tamil Code:")
        self.input_label.pack()

        self.input_text = scrolledtext.ScrolledText(root, height=15, width=80)
        self.input_text.pack()

        self.translate_button = tk.Button(root, text="Translate to C", command=self.translate)
        self.translate_button.pack(pady=10)

        self.output_label = tk.Label(root, text="Translated C Code:")
        self.output_label.pack()

        self.output_text = scrolledtext.ScrolledText(root, height=15, width=80)
        self.output_text.pack()

    def translate(self):
        tamil_code = self.input_text.get("1.0", tk.END).strip()
        if not tamil_code:
            messagebox.showwarning("Input Needed", "Please enter Tamil code to translate.")
            return

        c_code = tamil_to_c(tamil_code)
        self.output_text.delete("1.0", tk.END)
        self.output_text.insert(tk.END, c_code)

if __name__ == "__main__":
    root = tk.Tk()
    app = TamilToCApp(root)
    root.mainloop()
