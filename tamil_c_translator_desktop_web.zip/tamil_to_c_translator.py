import re

def tamil_to_c(tamil_code):
    translation_map = {
        "நிரல்பாகம்": "void",
        "முதலில்": "int main() {",
        "முடி": "}",
        "முடிவு": "return",
        "பதிப்பி": "printf",
        "பதிகொள்": "scanf",
        "எண்": "int",
        "மிதவை": "float",
        "நீளஎண்": "long",
        "எழுத்து": "char",
        "தனிச்சொல்": "string",
        "அரிசி": ";",
        "இணை": "=",
        "சமம்": "==",
        "மாறி": "!=",
        "அதிகம்": ">",
        "குறைவு": "<",
        "அதிகம்அல்லது சமம்": ">=",
        "குறைவுஅல்லது சமம்": "<=",
        "எனில்": "if",
        "இல்லையெனில்": "else if",
        "ஆனால்": "else",
        "முயற்சி": "for",
        "வரை": "while",
        "செய்": "do",
        "மற்றும்": "&&",
        "அல்லது": "||",
        "இல்லை": "!",
        "மாற்று": "switch",
        "வகை": "case",
        "இடைவெளி": "break",
        "தொடர்": "continue",
        "வடிவமைப்பு": "struct",
        "நிரல்": "program",
        "அச்சிடு": "puts",
        "நுழை": "gets"
    }

    sorted_keywords = sorted(translation_map.keys(), key=len, reverse=True)

    lines = tamil_code.split('\n')
    translated = []

    for line in lines:
        for tamil in sorted_keywords:
            c_equiv = translation_map[tamil]
            line = re.sub(rf'\b{re.escape(tamil)}\b', c_equiv, line)
        translated.append(line)

    return '\n'.join(translated)
